import sys
import unittest

from importer.common.common_util import time_format
from importer.data_import.data_events import events_debug_process


class MyTestCase(unittest.TestCase):
    def test_events(self):
        path = sys.path[0].replace('data_import', 'test_data/event.json')
        paths = [path]
        timezone = 'Asia/Shanghai'
        eventStart = time_format("2021-07-28", timezone)
        eventEnd = time_format("2021-08-27", timezone)
        self.assertEqual(events_debug_process(paths=paths, eventStart=eventStart, eventEnd=eventEnd), False)


if __name__ == '__main__':
    unittest.main()
