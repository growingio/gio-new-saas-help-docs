import sys
import unittest

from importer.data_import.data_user_variable import user_variables_debug_process


class MyTestCase(unittest.TestCase):
    def test_user_variable(self):
        path = sys.path[0].replace('data_import', 'test_data/user.json')
        paths = [path]
        self.assertEqual(user_variables_debug_process(paths=paths), False)


if __name__ == '__main__':
    unittest.main()
