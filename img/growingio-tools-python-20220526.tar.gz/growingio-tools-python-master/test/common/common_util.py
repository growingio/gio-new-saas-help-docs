import unittest

from importer.common.common_util import time_format


class MyTestCase(unittest.TestCase):
    def test_time_format(self):
        time_str = ['2021-08-01', '2021-08-01 11:11:11', '2021-08-01 11:11:11.111',
                    '2021/08/01', '2021/08/01 11:11:11', '2021/08/01 11:11:11.111', '1627824317000', '1627824317'
            , '1980-01-01', '315504000000']

        timezone = 'Asia/Shanghai'

        for time in time_str:
            self.assertEqual(True, isinstance(time_format(time, timezone), int))


if __name__ == '__main__':
    unittest.main()
