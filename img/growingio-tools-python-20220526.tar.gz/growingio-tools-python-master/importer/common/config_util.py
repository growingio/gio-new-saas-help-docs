#!/bin/env python3
# -*- coding: UTF-8 -*-

import os
import pathlib
from configparser import ConfigParser

config = ConfigParser()
config.read(os.path.abspath(str(pathlib.Path(os.path.abspath(__file__)).parent.parent) + "/conf.cfg"), encoding="UTF-8")

class ApiConfig:
    """A ApiConfig Class"""
    oauth2_uri = config['API']['oauth2_uri']
    username = config['API']['username']
    password = config['API']['password']


class BaseConfig:
    """A BaseConfig Class"""
    timezone = 'Asia/Shanghai'
    # 所有事件都有的事件属性
    attr_all = ["$session", "$path", "$referrer_path", "$textValue", "$index", "$xpath",
                "$hyperlink",
                "$duration", "$page_count", "$package", "$platform", "$referrer_domain",
                "$utm_source",
                "$utm_medium", "$utm_campaign", "$utm_term", "$utm_content", "$ads_id",
                "$key_word",
                "$country_code", "$country_name", "$region", "$city", "$browser",
                "$browser_version", "$os",
                "$os_version", "$client_version", "$channel", "$device_brand", "$device_model",
                "$device_type",
                "$device_orientation", "$resolution", "$language", "$referrer_type",
                "$account_id",
                "$domain",
                "$ip", "$user_agent", "$sdk_version", "$location_latitude",
                "$location_longitude",
                "$bot_id"]

class FTPConfig:
    host = ''
    user = ''
    password = ''
    port = ''


class SaasConfig:
    uri = config['SAAS']['saas_uri']
    token = config['SAAS']['saas_token']
    uid = config['SAAS']['saas_uid']
