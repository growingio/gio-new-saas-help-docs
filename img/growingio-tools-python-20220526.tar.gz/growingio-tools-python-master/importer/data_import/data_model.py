#!/bin/env python3
# -*- coding: UTF-8 -*-

# Copyright (c) 2020 growingio.com, Inc.  All Rights Reserved


class ImportBase:
    """
      Import Base
    """

    def __init__(self, name, path, debug, format, datasourceId, jobName):
        self.name = name
        self.path = path
        self.debug = debug
        self.format = format
        self.datasourceId = datasourceId
        self.jobName = jobName


class SVBase:
    """
      SV Base
    """

    def __init__(self, skipHeader, separator, qualifier='"'):
        self.qualifier = qualifier
        self.separator = separator
        self.skipHeader = skipHeader


class UserVariables(ImportBase):
    """
      用户属性
    """

    def __init__(self, name, path, debug, format, datasourceId, jobName):
        ImportBase.__init__(self, name, path, debug, format, datasourceId, jobName)


class UserVariablesJson(UserVariables):
    """
      用户属性-Josn格式
    """

    def __init__(self, name, path, format, datasourceId, jobName, debug=True):
        UserVariables.__init__(self, name, path, debug, format, datasourceId, jobName)


class UserVariablesSv(UserVariables, SVBase):
    """
      用户属性-CSV/TSV格式
    """

    def __init__(self, name, path, debug, format, datasourceId, jobName, attributes, skipHeader, separator,
                 qualifier='"'):
        UserVariables.__init__(self, name, path, debug, format, datasourceId, jobName)
        SVBase.__init__(self, skipHeader, separator, qualifier)
        self.attributes = attributes


class Events(ImportBase):
    """
      用户行为
    """

    def __init__(self, name, path, debug, format, datasourceId, eventStart, eventEnd, jobName):
        ImportBase.__init__(self, name, path, debug, format, datasourceId, jobName)
        self.eventStart = eventStart
        self.eventEnd = eventEnd
        self.jobName = jobName


class EventsJson(Events):
    """
      用户行为-Josn格式
    """

    def __init__(self, name, path, format, datasourceId, eventStart, eventEnd, jobName, debug=True):
        Events.__init__(self, name, path, debug, format, datasourceId, eventStart, eventEnd, jobName)


class EventsCv(Events, SVBase):
    """
      用户行为-CSV/TSV格式
    """

    def __init__(self, name, path, debug, format, datasourceId, eventStart, eventEnd, jobName, attributes, skipHeader,
                 separator, qualifier='"'):
        Events.__init__(self, name, path, debug, format, datasourceId, eventStart, eventEnd, jobName)
        SVBase.__init__(self, skipHeader, separator, qualifier)
        self.attributes = attributes


class DataEvent:
    """
      用户行为大数据规定格式
    """

    def __init__(self, userId, event, timestamp, attrs, userKey='', eventId=''):
        self.userId = userId
        self.event = event
        self.userKey = userKey
        self.eventId = eventId
        self.timestamp = timestamp
        self.attrs = attrs


class DataUser:
    """
      用户属性大数据规定格式
    """

    def __init__(self, userId, attrs):
        self.userId = userId
        self.attrs = attrs
