PREFIX=$(pwd)/ffout
FFMPEG_CONFIGS="  --disable-doc \
  --disable-programs\
  --disable-avdevice \
  --enable-avfilter \
  --disable-encoders \
  --disable-muxers \
  --disable-filters \
  --disable-devices \
  --disable-debug \
  --enable-small \
  --enable-filter=atempo \
  --enable-version3 \
  --prefix=$PREFIX"
  
  ./configure $FFMPEG_CONFIGS
  make -j4
  make install 
  make clean
  