var gThunderStatus = 0;
var gThunderVersion = '3.3';

safari.self.addEventListener("ThunderVersion", thunderVersion);
safari.self.addEventListener("ThunderStatus", onThunderStatusChange);
safari.extension.dispatchMessage("GetThunderVersion", {'host': window.location.host});
safari.extension.dispatchMessage("CheckDownloadStatus", {'host': window.location.host});

if (window === window.top) {
    document.addEventListener("click", onDocClick, true);
}

function thunderVersion(userInfo) {
    gThunderVersion = userInfo['version'];
    console.log("thunder version:" + gThunderVersion);
}

function onThunderStatusChange(userInfo) {
    gThunderStatus = userInfo['status'];
}

function onDocClick(event) {
    // 忽略command按钮点击事件
    if (event.metaKey == true) return;
    var e = event.target ? event.target : event.srcElement;
    if(e.nodeName.toUpperCase() != "A"){
        e = e.parentNode;
    }
    
    if(e.nodeName.toUpperCase() == "A"){
        var url = e.href;
        
        if (isSupportDownloadURL(url) == false ) {
            var attrs = e.attributes;
            var foundThunder = false;
            for(var idx=attrs.length; idx>=0; idx--) {
                var obj = attrs[idx];
                if (typeof(obj) === 'object') {
                    var val = obj.value;
                    if (val !== undefined && val.startsWith("thunder://")) {
                        url = val;
                        foundThunder = true;
                        break;
                    }
                }
            }
            
            if (foundThunder == false && isSupportDownloadURL(objectInnerText)) {
                url = objectInnerText;
            }
        }
        
        var ret = downloadByThunder(url);
        if(ret){
            event.preventDefault();
            event.stopPropagation();
        }
    }
}

function downloadByThunder(url) {
    
    if (gThunderStatus != 0) return false;
    
    if (isSupportDownloadURL(url) == false) return false;
    
    safari.extension.dispatchMessage("DownloadByThunder", {
                                     'url': url,
                                     'ref': window.top.location.href
                                     });
    return true;
}

function isSupportDownloadURL(downloadUrl) {
    var schemeArray = ["http","https","ftp","ftps","thunder","ed2k","magnet"];
    
    var splitUrlArray = downloadUrl.split(":");
    
    var schemeStr = "";
    if(splitUrlArray.length > 1)
    {
        schemeStr = splitUrlArray[0];
    }
    
    if (schemeStr == "")
    {
        return false;
    }
    if (schemeArray.indexOf(schemeStr) == -1)
    {
        return false;
    }
    if (schemeStr == "thunder" || schemeStr == "ed2k" || schemeStr == "magnet")
    {
        return true;
    }
    
    var extArray = ["3g2","3gp","3gp2","3gpp","flv","f4v","flc","fli","flic","asf","avi","csf","dat","divx","evo","ifo","m1v","m2p","m2ts","m2v","m4b","m4p","m4v","mkv","mov","mp2v","mp4","mpe","mpeg","mpeg1","mpeg2","mpeg4","mpg","mpv2","pmp","pss","pva","qt","ram","rm","rmvb","rp","rpm","rt","smi","smil","tp","tpr","ts","vob","vp6","wm","wma","wmp","wmv","asm","asx","avsts","bik","d2v","dsa","dsm","dss","dsv","hlv","ivf","ivm","kpl","m3u","mpcpl","mts","ogm","pls","pmp2","qpl","ratdvd","realpix","rmi","scm","smk","smpl","tod","vg2","vid","wax","wmx","wv","wvx","ogv","ogx","ogg","mp3","flac","musepack","ape","shorten","wavpack","aac","apple lossless","wave","aiff","nsf","gbs","gym","spc","vgm","hes","it","s3m","xm","mod","m3u","pls","cue","deb","dmg","apk","msi","sis","sisx","pkg","exe","ipsw","zip","rar","7z","tar","gz","gz2","bz2","iso","torrent"];
    
    var extname = "";
    var splitUrlByPointArray = downloadUrl.split(".");
    var length =  splitUrlByPointArray.length;
    if(length > 1)
    {
        extname = splitUrlByPointArray[length-1];
    }
    
    if(extname == "")
    {
        return false;
    }
    if(extArray.indexOf(extname) >-1)
    {
        return true;
    }
    
    return false;
}
